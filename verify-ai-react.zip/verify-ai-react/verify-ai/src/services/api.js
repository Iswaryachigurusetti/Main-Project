const BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

async function request(endpoint, options = {}) {
  try {
    const res = await fetch(`${BASE_URL}${endpoint}`, {
      headers: { "Content-Type": "application/json", ...options.headers },
      ...options,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: res.statusText }));
      throw new Error(err.detail || `Request failed with status ${res.status}`);
    }
    return await res.json();
  } catch (error) {
    console.warn(`API call failed [${endpoint}]:`, error);
    throw error;
  }
}

export const api = {
  getTrendingClaims: () => request("/api/claims/trending"),
  getClaimById: (id) => request(`/api/claims/${id}`),
  predictClaim: (text) =>
    request("/api/predict", {
      method: "POST",
      body: JSON.stringify({ text }),
    }),
  askChat: (question, claimId = null) =>
    request("/api/chat", {
      method: "POST",
      body: JSON.stringify({ question, claim_id: claimId }),
    }),
  getDriftStatus: () => request("/api/drift"),
  getInsights: () => request("/api/insights"),
  getBookmarks: () => request("/api/bookmarks"),
  addBookmark: (claimId) =>
    request("/api/bookmarks", {
      method: "POST",
      body: JSON.stringify({ claim_id: claimId }),
    }),
  removeBookmark: (claimId) =>
    request(`/api/bookmarks/${claimId}`, { method: "DELETE" }),
  getActivity: () => request("/api/activity"),
  recordActivity: (claimId, action = "checked") =>
    request("/api/activity", {
      method: "POST",
      body: JSON.stringify({ claim_id: claimId, action }),
    }),
  sendFeedback: (claimId, feedbackType, rating = null, comment = null) =>
    request("/api/feedback", {
      method: "POST",
      body: JSON.stringify({
        claim_id: claimId,
        feedback_type: feedbackType,
        rating,
        comment,
      }),
    }),
};