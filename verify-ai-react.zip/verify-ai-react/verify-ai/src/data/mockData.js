export const VERDICT = {
  reliable: { label: "Reliable", color: "#1E9E62", bg: "#E6F6ED", Icon: "ShieldCheck" },
  unverified: { label: "Needs Verification", color: "#B8790C", bg: "#FDF3DF", Icon: "ShieldQuestion" },
  misinformation: { label: "Likely Misinformation", color: "#D93025", bg: "#FCE8E6", Icon: "ShieldAlert" },
};

export const CATEGORIES = [
  "All",
  "Education & Examinations",
  "Government Schemes",
  "Finance & Economy",
  "Technology & AI",
  "Public Announcements"
];

export const TOPICS = CATEGORIES;
export const FILTERS = ["All", "Reliable", "Misinformation", "Unverified"];

const SOURCE_POOL = {
  reliable: [
    { 
      name: "Press Information Bureau (PIB)", 
      domain: "pib.gov.in", 
      reliability: 98, 
      snippet: "Official government release confirms authenticated policy guidelines and verified timelines." 
    },
    { 
      name: "APSCHE Official Examination Portal", 
      domain: "cets.apsche.ap.gov.in", 
      reliability: 100, 
      snippet: "Official APPGECET/PGCET notifications confirm registration schedules, web options, and verified counseling procedures." 
    },
    { 
      name: "Reserve Bank of India", 
      domain: "rbi.org.in", 
      reliability: 98, 
      snippet: "Statutory regulatory guidelines published via central banking and monetary directives." 
    },
    { 
      name: "UIDAI Official Portal", 
      domain: "uidai.gov.in", 
      reliability: 96, 
      snippet: "Official authority circular regarding authentication guidelines and demographic update procedures." 
    },
  ],
  unverified: [
    { 
      name: "State Higher Education Repository", 
      domain: "education.gov.in", 
      reliability: 72, 
      snippet: "Draft regulatory circular under review; pending formal gazette publication." 
    },
    { 
      name: "Regional News Feed", 
      domain: "newswire.in", 
      reliability: 60, 
      snippet: "Multiple media reports circulating based on preliminary statements; official order awaited." 
    },
  ],
  misinformation: [
    { 
      name: "PIB Fact Check Unit", 
      domain: "factcheck.pib.gov.in", 
      reliability: 100, 
      snippet: "Official Fact Check: This claim has been investigated and confirmed to be completely fabricated." 
    },
    { 
      name: "Reserve Bank of India Advisory", 
      domain: "rbi.org.in", 
      reliability: 98, 
      snippet: "RBI Advisory: No such authorization or withdrawal order exists under regulatory frameworks." 
    },
  ],
};

function makeClaim(id, verdict, o) {
  return {
    id,
    verdict,
    confidence: o.confidence ?? (verdict === "unverified" ? 58 : 96),
    title: o.title,
    category: o.category,
    fullText: o.fullText,
    trendLevel: o.trendLevel,
    engagement: o.engagement,
    growth: o.growth,
    time: o.time,
    words: o.words,
    explanation: o.explanation,
    sources: o.sources ?? SOURCE_POOL[verdict],
    model: "StreamGuard-XAI v2.3 · Incremental ensemble",
    userSubmitted: false,
  };
}

export const CLAIMS = [
  makeClaim("c1", "misinformation", {
    title: "PIB Fact Check: Viral video claiming Government distributing free scooters on ID submission is fake",
    category: "Government Schemes",
    fullText: "A viral video circulating across social platforms claims that the Central Government is providing free electric scooters to citizens who submit their personal identification details through an unofficial link.",
    trendLevel: 96,
    engagement: "142K",
    growth: "+240%",
    time: "Trending on X",
    words: [["free scooter", 0.96], ["identity submission", 0.91], ["forward message", 0.88], ["urgent confirmation", 0.74]],
    explanation: "The PIB Fact Check Unit investigated the viral video and confirmed no such welfare initiative exists. The model flagged high urgency phrasing and suspicious link redirection patterns.",
    sources: [
      {
        name: "PIB Fact Check Official Unit",
        domain: "factcheck.pib.gov.in",
        reliability: 100,
        snippet: "Clarification: The viral claim regarding free scooter allocation upon ID submission is entirely fabricated."
      },
      {
        name: "X (Twitter) Social Discourse",
        domain: "x.com",
        reliability: 65,
        snippet: "Security analysts on X warned users against phishing forms masquerading as official welfare registration portals."
      }
    ]
  }),
  makeClaim("c2", "reliable", {
    title: "APPGECET 2026: Official Examination Schedule and Registration Window Released by APSCHE",
    category: "Education & Examinations",
    fullText: "APPGECET 2026 Post Graduate Engineering Common Entrance Test notification issued by Andhra University on behalf of APSCHE. Registration fee set at Rs. 1200 for OC, Rs. 900 for BC, and Rs. 700 for SC/ST.",
    trendLevel: 92,
    engagement: "84K",
    growth: "+180%",
    time: "Official Release",
    words: [["appgecet", 0.97], ["apsche", 0.94], ["andhra university", 0.91], ["examination schedule", 0.86]],
    explanation: "Corroborated directly by statutory releases from the Andhra Pradesh State Council of Higher Education (APSCHE) and university portals.",
    sources: [
      {
        name: "APSCHE Official Examination Portal",
        domain: "cets.apsche.ap.gov.in",
        reliability: 100,
        snippet: "APPGECET 2026: Online application window open; Examinations scheduled April 28–30, 2026; Preliminary key release May 6, 2026."
      },
      {
        name: "AP State Council of Higher Education",
        domain: "apsche.ap.gov.in",
        reliability: 100,
        snippet: "Statutory authority circular confirming fee structures and admission counseling procedures."
      }
    ]
  }),
  makeClaim("c3", "misinformation", {
    title: "RBI Advisory: Viral messages claiming guaranteed daily returns on AI investment platforms are fraudulent",
    category: "Finance & Economy",
    fullText: "Social media advertisements featuring deepfakes of public figures falsely assert high-yield automated investment platforms offering guaranteed daily returns on small deposits.",
    trendLevel: 89,
    engagement: "61K",
    growth: "+115%",
    time: "Viral Alert",
    words: [["guaranteed return", 0.95], ["daily income", 0.92], ["unregulated app", 0.87], ["deepfake", 0.83]],
    explanation: "Statutory regulators have published alerts warning against fraudulent platforms using manipulated media to promote unauthorized trading schemes.",
    sources: [
      {
        name: "Reserve Bank of India Advisory",
        domain: "rbi.org.in",
        reliability: 100,
        snippet: "Public Warning: Regulatory bodies have not approved automated trading schemes promising guaranteed fixed returns."
      },
      {
        name: "Press Information Bureau Fact Check",
        domain: "pib.gov.in",
        reliability: 100,
        snippet: "Debunked: Fabricated videos of public figures endorsing financial schemes are deceptive and illegal."
      }
    ]
  }),
  makeClaim("c4", "reliable", {
    title: "UIDAI Clarification: Standard demographic updates at official centres follow published guidelines",
    category: "Public Announcements",
    fullText: "UIDAI has reiterated that demographic updates through official enrolment centres follow standard published fee schedules, warning the public against third-party intermediaries charging excessive fees.",
    trendLevel: 67,
    engagement: "41K",
    growth: "+38%",
    time: "3h ago",
    words: [["official centres", 0.72], ["published schedule", 0.68], ["UIDAI reiterated", 0.66], ["warned against", 0.52]],
    explanation: "Matches official notifications from the issuing statutory authority, utilizing measured regulatory terminology verified across public portals.",
  }),
  makeClaim("c5", "unverified", {
    title: "Reports of revised daily limits for peer-to-merchant UPI transactions under review",
    category: "Finance & Economy",
    fullText: "Reports circulating suggest standard daily transaction caps for specific merchant categories may be updated, though official regulatory guidelines are pending final circular release.",
    trendLevel: 81,
    engagement: "64K",
    growth: "+120%",
    time: "1h ago",
    words: [["daily limit", 0.58], ["merchant payments", 0.49], ["reports circulating", 0.62]],
    explanation: "The claim references an active policy domain, but in the absence of a published gazette circular, the model assigns an unverified status.",
  }),
  makeClaim("c6", "reliable", {
    title: "RBI Official Notice: No proposal to alter or withdraw circulating currency denominations",
    category: "Finance & Economy",
    fullText: "The Reserve Bank of India has clarified that valid legal tender currency notes in circulation remain fully active, addressing recurring social media rumors.",
    trendLevel: 59,
    engagement: "33K",
    growth: "+22%",
    time: "5h ago",
    words: [["RBI clarifies", 0.75], ["legal tender", 0.69], ["no withdrawal", 0.66]],
    explanation: "Direct statement from the central banking authority refuting unverified claims regarding currency circulation.",
  }),
  makeClaim("c7", "misinformation", {
    title: "Phishing Warning: Fraudulent alerts claim bank accounts face immediate freeze within 24 hours",
    category: "Finance & Economy",
    fullText: "Deceptive SMS and messaging alerts claim customer bank accounts will be suspended within 24 hours unless personal verification is completed via an unverified third-party link.",
    trendLevel: 85,
    engagement: "112K",
    growth: "+265%",
    time: "Viral Alert",
    words: [["frozen within 24h", 0.94], ["unverified link", 0.89], ["immediate suspension", 0.78]],
    explanation: "Artificial time pressure combined with suspicious URL redirection matches known phishing patterns rather than official banking protocols.",
  }),
  makeClaim("c8", "reliable", {
    title: "Ministry of Education releases official schedule for upcoming academic terms",
    category: "Education & Examinations",
    fullText: "The Ministry of Education has published the structured academic calendar and entrance examination timeframes via an official gazette circular.",
    trendLevel: 48,
    engagement: "21K",
    growth: "+15%",
    time: "7h ago",
    words: [["official circular", 0.68], ["Ministry confirms", 0.64], ["gazette notification", 0.58]],
    explanation: "Verifiable circular published through official government ministry repositories.",
  }),
];

export const DRIFT_EVENTS = [
  { time: "2h ago", detail: "Minor drift detected in 'urgency-language' feature distribution — model recalibrated automatically." },
  { time: "1d ago", detail: "Incremental update applied after 1,240 new labelled streaming samples." },
  { time: "3d ago", detail: "Concept drift flagged in finance-category claims; ADWIN window reset, retraining completed in 4m 12s." },
];

export const SUGGESTED = [
  "What are the official APPGECET counselling dates?",
  "Is the free government scooter scheme real?",
  "How does this model detect concept drift?",
  "Why was this claim flagged by the SGD model?",
  "Show me the official statutory sources.",
  "Explain the feature attribution weights."
];

export { SOURCE_POOL };