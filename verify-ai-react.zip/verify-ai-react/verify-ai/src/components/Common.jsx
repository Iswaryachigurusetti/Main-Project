import { ShieldCheck, ShieldAlert, ShieldQuestion, TrendingUp, ExternalLink } from "lucide-react";
import { VERDICT } from "../data/mockData.js";

const ICONS = { ShieldCheck, ShieldAlert, ShieldQuestion };

export function VerdictPill({ verdict, size = "md" }) {
  const v = VERDICT[verdict];
  const Icon = ICONS[v.Icon];
  return (
    <span className={`verdict-pill ${size === "sm" ? "verdict-pill--sm" : ""}`} style={{ color: v.color, background: v.bg }}>
      <Icon size={size === "sm" ? 13 : 15} strokeWidth={2.4} />
      {v.label}
    </span>
  );
}

export function ConfidenceGauge({ confidence, verdict, size = 108 }) {
  const v = VERDICT[verdict];
  const r = (size - 14) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (confidence / 100) * c;
  return (
    <div className="gauge" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#E4E7EC" strokeWidth="9" fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={v.color} strokeWidth="9" fill="none"
          strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round" className="gauge-arc" />
      </svg>
      <div className="gauge-label">
        <span className="gauge-value" style={{ color: v.color }}>{confidence}%</span>
        <span className="gauge-caption">confidence</span>
      </div>
    </div>
  );
}

export function StatCard({ icon: Icon, label, value, accent }) {
  return (
    <div className="stat-card">
      <div className="stat-icon" style={{ background: `${accent}1a`, color: accent }}>
        <Icon size={16} />
      </div>
      <div>
        <p className="stat-value">{value}</p>
        <p className="stat-label">{label}</p>
      </div>
    </div>
  );
}

export function SourceCard({ source }) {
  // Check if snippet contains table or bullet formatted text
  const isTable = source.snippet && source.snippet.includes("|");
  const isBulletList = source.snippet && source.snippet.includes("•");

  const renderSnippet = () => {
    if (isTable) {
      const rows = source.snippet
        .split("\n")
        .filter((r) => r.trim() && !r.includes("---"))
        .map((r) => r.split("|").map((c) => c.trim()).filter(Boolean));

      if (rows.length > 1) {
        return (
          <div className="source-table-wrap" style={{ overflowX: "auto", margin: "10px 0" }}>
            <table style={{ width: "100%", fontSize: "0.82rem", borderCollapse: "collapse", textAlign: "left" }}>
              <thead>
                <tr style={{ borderBottom: "2px solid #E4E7EC", color: "#344054" }}>
                  {rows[0].map((h, i) => (
                    <th key={i} style={{ padding: "6px 8px", fontWeight: "600" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.slice(1).map((row, rIdx) => (
                  <tr key={rIdx} style={{ borderBottom: "1px solid #F2F4F7" }}>
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} style={{ padding: "6px 8px", color: "#475467" }}>{cell}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      }
    }

    if (isBulletList) {
      const items = source.snippet.split("•").map((i) => i.trim()).filter(Boolean);
      return (
        <ul style={{ paddingLeft: "18px", margin: "8px 0", fontSize: "0.88rem", color: "#475467", lineHeight: "1.5" }}>
          {items.map((item, idx) => (
            <li key={idx} style={{ marginBottom: "4px" }}>{item}</li>
          ))}
        </ul>
      );
    }

    return <p className="source-snippet">"{source.snippet}"</p>;
  };

  return (
    <div className="source-card">
      <div className="source-card-top">
        <div>
          <p className="source-name">{source.name}</p>
          <p className="source-domain">{source.domain}</p>
        </div>
        <div
          className="source-reliability"
          style={{
            color: source.reliability >= 95 ? "#1E9E62" : source.reliability > 65 ? "#B8790C" : "#D93025",
            fontWeight: "600"
          }}
        >
          {source.reliability}% reliable
        </div>
      </div>
      {renderSnippet()}
      <div className="source-card-bottom">
        <span className="source-tag">Evidence from external source</span>
        <a
          href={source.domain.startsWith("http") ? source.domain : `https://${source.domain}`}
          target="_blank"
          rel="noopener noreferrer"
          className="source-link"
          style={{ textDecoration: "none", color: "#3B78E7", display: "inline-flex", alignItems: "center", gap: "4px" }}
        >
          <ExternalLink size={12} /> View official portal
        </a>
      </div>
    </div>
  );
}


export function WordWeightBar({ word, weight }) {
  return (
    <div className="word-row">
      <span className="word-label">{word}</span>
      <div className="word-track"><div className="word-fill" style={{ width: `${weight * 100}%` }} /></div>
      <span className="word-value">{Math.round(weight * 100)}</span>
    </div>
  );
}

export function ClaimRow({ claim, onOpen, onBookmark, bookmarked, reason }) {
  const v = VERDICT[claim.verdict];
  return (
    <button className="claim-row" onClick={() => onOpen(claim.id)}>
      <span className="claim-row-stripe" style={{ background: v.color }} />
      <div className="claim-row-body">
        <div className="claim-row-meta">
          <VerdictPill verdict={claim.verdict} size="sm" />
          <span className="claim-row-category">{claim.category}</span>
          {reason && <span className="claim-row-reason">✦ {reason}</span>}
        </div>
        <h3 className="claim-row-title">{claim.title}</h3>
        <div className="claim-row-stats">
          <span><TrendingUp size={12} /> {claim.growth} growth</span>
          <span>{claim.engagement} discussing</span>
          <span>{claim.time}</span>
        </div>
      </div>
      <div className="claim-row-actions">
        <span className="bookmark-btn" onClick={(e) => { e.stopPropagation(); onBookmark(claim.id); }}>
          {bookmarked ? "★" : "☆"}
        </span>
        <span className="chevron">›</span>
      </div>
    </button>
  );
}
