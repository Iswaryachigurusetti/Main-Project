import { useState, useEffect, useRef } from "react";
import { Sparkles, Send } from "lucide-react";
import { SUGGESTED } from "../data/mockData.js";

// Formatter component to convert markdown text into structured React elements
function FormattedMessage({ text }) {
  if (!text) return null;

  // Split into lines for structured rendering
  const lines = text.split("\n");

  const renderInline = (str) => {
    // Convert **bold** tokens
    const parts = str.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, idx) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return <strong key={idx}>{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="chat-markdown-body">
      {lines.map((line, lIdx) => {
        const trimmed = line.trim();

        // Empty line -> spacing
        if (!trimmed) {
          return <div key={lIdx} style={{ height: "6px" }} />;
        }

        // Bullet list item
        if (trimmed.startsWith("•") || trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
          const bulletText = trimmed.replace(/^[•\-*]\s*/, "");
          return (
            <div key={lIdx} style={{ display: "flex", gap: "8px", margin: "3px 0", paddingLeft: "4px" }}>
              <span style={{ color: "var(--blue)", fontWeight: "bold" }}>•</span>
              <span style={{ flex: 1 }}>{renderInline(bulletText)}</span>
            </div>
          );
        }

        // Numbered list item (e.g. "1. Notification:")
        if (/^\d+\.\s/.test(trimmed)) {
          const match = trimmed.match(/^(\d+\.)\s*(.*)$/);
          return (
            <div key={lIdx} style={{ display: "flex", gap: "8px", margin: "3px 0", paddingLeft: "4px" }}>
              <span style={{ fontWeight: "600", color: "var(--text-dim)" }}>{match[1]}</span>
              <span style={{ flex: 1 }}>{renderInline(match[2])}</span>
            </div>
          );
        }

        // Headings (### Title)
        if (trimmed.startsWith("###") || trimmed.startsWith("##")) {
          const headingText = trimmed.replace(/^#+\s*/, "");
          return (
            <p key={lIdx} style={{ fontWeight: "700", marginTop: "8px", marginBottom: "4px", fontSize: "14px" }}>
              {renderInline(headingText)}
            </p>
          );
        }

        // Standard Paragraph
        return (
          <p key={lIdx} style={{ margin: "2px 0", lineHeight: "1.5" }}>
            {renderInline(trimmed)}
          </p>
        );
      })}
    </div>
  );
}

export default function ChatPanel({ claim, messages, onSend, placeholder }) {
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const submit = (text) => {
    const t = (text ?? input).trim();
    if (!t) return;
    setInput("");
    onSend(t, setTyping);
  };

  return (
    <div className="chat-panel">
      <div className="chat-header">
        <div className="chat-avatar">
          <Sparkles size={14} color="#fff" />
        </div>
        <div>
          <p className="chat-title">Fact-checking assistant</p>
          <p className="chat-subtitle">{claim ? `Context: ${claim.title.slice(0, 45)}...` : "General claim verification"}</p>
        </div>
      </div>

      <div className="chat-body">
        {messages.length === 0 && (
          <div className="chip-row">
            {SUGGESTED.map((s) => (
              <button key={s} className="chip" onClick={() => submit(s)}>
                {s}
              </button>
            ))}
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={`chat-bubble ${m.role === "user" ? "chat-bubble--user" : "chat-bubble--ai"}`}>
            {m.role === "user" ? m.text : <FormattedMessage text={m.text} />}
          </div>
        ))}

        {typing && (
          <div className="chat-bubble chat-bubble--ai chat-typing">
            <span></span>
            <span></span>
            <span></span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="chat-input-row">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={placeholder ?? "Ask about this claim…"}
          className="chat-input"
        />
        <button className="chat-send" onClick={() => submit()}>
          <Send size={14} color="#fff" />
        </button>
      </div>
    </div>
  );
}