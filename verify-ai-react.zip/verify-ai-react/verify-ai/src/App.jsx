import { useState, useEffect } from "react";
import { api } from "./services/api.js";
import { CLAIMS as FALLBACK_CLAIMS } from "./data/mockData.js";
import { Header, MobileDrawer, MobileNav, Toasts } from "./components/Layout.jsx";
import { HomeView, TrendingView, VerifyView, AssistantView, ActivityView, InsightsView } from "./pages/Pages.jsx";
import ClaimDetail from "./pages/ClaimDetail.jsx";

export default function App() {
  const [view, setView] = useState("home");
  const [selectedId, setSelectedId] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [bookmarks, setBookmarks] = useState([]);
  const [activity, setActivity] = useState([]);
  const [chatByClaimId, setChatByClaimId] = useState({});
  const [feedbackByClaimId, setFeedbackByClaimId] = useState({});
  const [toasts, setToasts] = useState([]);
  const [liveTick, setLiveTick] = useState(0);

  // Live Claims State from Backend
  const [claims, setClaims] = useState(FALLBACK_CLAIMS);

  // 1. Fetch live claims from FastAPI database on mount
  useEffect(() => {
    async function loadLiveTrending() {
      try {
        const liveData = await api.getTrendingClaims();
        if (Array.isArray(liveData) && liveData.length > 0) {
          setClaims(liveData);
        }
      } catch (err) {
        console.warn("Using fallback trending data (backend offline):", err);
      }
    }
    loadLiveTrending();

    // Poll for new streamed claims every 15 seconds
    const interval = setInterval(loadLiveTrending, 15000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setLiveTick((v) => v + Math.floor(Math.random() * 4)), 4000);
    return () => clearInterval(t);
  }, []);

  const addToast = (msg) => {
    const id = Date.now();
    setToasts((t) => [...t, { id, msg }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  };

  const goto = (v) => { setView(v); setMobileOpen(false); };

  const openClaim = (id) => {
    setSelectedId(id); setView("claimDetail");
    setActivity((a) => (a.find((x) => x.claimId === id) ? a : [{ claimId: id, at: Date.now() }, ...a]));
  };

  const toggleBookmark = (id) => {
    setBookmarks((b) => (b.includes(id) ? b.filter((x) => x !== id) : [...b, id]));
    addToast(bookmarks.includes(id) ? "Removed from saved" : "Saved for later");
  };

  const sendChat = async (claimId, text, setTyping) => {
    setChatByClaimId((c) => ({ ...c, [claimId]: [...(c[claimId] || []), { role: "user", text }] }));
    setTyping(true);

    try {
      const res = await api.askChat(text, claimId);
      setChatByClaimId((c) => ({ ...c, [claimId]: [...(c[claimId] || []), { role: "ai", text: res.text }] }));
    } catch (err) {
      console.warn("Chat error:", err);
    } finally {
      setTyping(false);
    }
  };

  const selected = claims.find((c) => c.id === selectedId);

  return (
    <div className="app">
      <Header view={view} goto={goto} query={query} setQuery={setQuery} setMobileOpen={setMobileOpen} addToast={addToast} />
      <MobileDrawer open={mobileOpen} onClose={() => setMobileOpen(false)} view={view} goto={goto} />

      <main className="main">
        {view === "home" && <HomeView claims={claims} onOpen={openClaim} bookmarks={bookmarks} onBookmark={toggleBookmark} liveTick={liveTick} />}
        {view === "trending" && <TrendingView claims={claims} onOpen={openClaim} bookmarks={bookmarks} onBookmark={toggleBookmark} query={query} />}
        {view === "verify" && <VerifyView addToast={addToast} />}
        {view === "assistant" && <AssistantView addToast={addToast} />}
        {view === "activity" && <ActivityView activity={activity} claims={claims} onOpen={openClaim} bookmarks={bookmarks} onBookmark={toggleBookmark} />}
        {view === "insights" && <InsightsView claims={claims} />}
        {view === "claimDetail" && selected && (
          <ClaimDetail
            claim={selected}
            onBack={() => setView("trending")}
            bookmarked={bookmarks.includes(selected.id)}
            onBookmark={toggleBookmark}
            chatMessages={chatByClaimId[selected.id] || []}
            onSend={(text, setTyping) => sendChat(selected.id, text, setTyping)}
            feedback={feedbackByClaimId[selected.id]}
            onFeedback={(id, f) => setFeedbackByClaimId((s) => ({ ...s, [id]: f }))}
            addToast={addToast}
          />
        )}
      </main>

      <MobileNav view={view} goto={goto} />
      <Toasts toasts={toasts} />
    </div>
  );
}